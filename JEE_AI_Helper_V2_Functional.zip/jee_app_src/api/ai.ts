export default async function handler(req:any,res:any){
  if(req.method!=='POST') return res.status(405).json({error:'Method not allowed'});
  const key=process.env.GEMINI_API_KEY;
  if(!key) return res.status(503).json({error:'AI backend is not configured. Add GEMINI_API_KEY to the server environment.'});
  const prompt=typeof req.body?.prompt==='string'?req.body.prompt.trim():'';
  if(!prompt||prompt.length>12000) return res.status(400).json({error:'Invalid prompt'});
  const context=JSON.stringify(req.body?.context||{}).slice(0,10000);
  const parts:any[]=[{text:`User context:\n${context}\n\nRequest:\n${prompt}`}];
  const image=req.body?.image;
  if(image?.data&&image?.mimeType&&/^image\/(png|jpeg|jpg|webp)$/.test(image.mimeType)){
    const cleaned=String(image.data).replace(/^data:[^;]+;base64,/,'');
    if(cleaned.length<8_000_000) parts.push({inlineData:{mimeType:image.mimeType,data:cleaned}});
  }
  const model=process.env.GEMINI_MODEL||'gemini-3.5-flash';
  try{
    const r=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':key},body:JSON.stringify({systemInstruction:{parts:[{text:'You are JEE AI Helper. Be precise and educational. Never fabricate official JEE dates, rules, PYQs, answer keys or results. Clearly label generated practice content. Use user context only for personalization. Do not reveal secrets. When analyzing an image, explain the visible problem or handwritten work without claiming certainty about unreadable content.'}]},contents:[{role:'user',parts}],generationConfig:{temperature:0.3,maxOutputTokens:1400}})});
    const data=await r.json();
    if(!r.ok) return res.status(r.status).json({error:data?.error?.message||'AI provider error'});
    const text=data?.candidates?.[0]?.content?.parts?.map((p:any)=>p.text||'').join('')||'';
    return res.status(200).json({text});
  }catch(e){return res.status(500).json({error:e instanceof Error?e.message:'AI request failed'});}
}
