import { useState } from 'react';
import { Star, BookOpen, ChevronDown, ChevronRight, AlertTriangle, TrendingUp, Search, Filter } from 'lucide-react';
import { FORMULAS, Formula, SubjectKey } from '../data/content';
import { addRevision } from '../lib/appStore';

const subjectColors: Record<string, string> = { physics: '#3b82f6', chemistry: '#10b981', math: '#f59e0b' };

export default function FormulaBank() {
  const [search, setSearch] = useState('');
  const [subjectFilter, setSubjectFilter] = useState<'all' | SubjectKey>('all');
  const [favorites, setFavorites] = useState<string[]>(FORMULAS.filter(f => f.isFavorite).map(f => f.id));
  const [expanded, setExpanded] = useState<string[]>([]);
  const [showFavOnly, setShowFavOnly] = useState(false);

  const filtered = FORMULAS.filter(f => {
    if (showFavOnly && !favorites.includes(f.id)) return false;
    if (subjectFilter !== 'all' && f.subject !== subjectFilter) return false;
    if (search && !f.name.toLowerCase().includes(search.toLowerCase()) && !f.formula.toLowerCase().includes(search.toLowerCase()) && !f.chapter.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const toggleFav = (id: string) => setFavorites(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  const toggleExpand = (id: string) => setExpanded(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);

  return (
    <div className="p-4 lg:p-6 max-w-5xl mx-auto space-y-4">
      <div className="flex items-start justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-display text-2xl font-700 text-[var(--foreground)]">Formula Bank</h1>
          <p className="text-[var(--muted-foreground)] text-sm mt-0.5">{FORMULAS.length} formulas · Physics, Chemistry, Mathematics</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => setShowFavOnly(!showFavOnly)} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-500 transition-all ${showFavOnly ? '' : 'opacity-70'}`} style={{ background: '#f59e0b20', color: '#f59e0b' }}>
            <Star size={12} fill={showFavOnly ? 'currentColor' : 'none'} /> Favorites ({favorites.length})
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[180px]">
          <Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[var(--muted-foreground)]" />
          <input className="input pl-8 text-xs" placeholder="Search formulas..." value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <div className="flex gap-1">
          {(['all', 'physics', 'chemistry', 'math'] as const).map(s => (
            <button key={s} onClick={() => setSubjectFilter(s)}
              className={`px-3 py-1.5 rounded-lg text-xs font-500 transition-all capitalize ${subjectFilter === s ? 'text-white' : 'text-[var(--muted-foreground)]'}`}
              style={{ background: subjectFilter === s ? (s === 'all' ? 'var(--primary)' : subjectColors[s]) : 'var(--secondary)' }}>
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Formula cards */}
      <div className="space-y-3">
        {filtered.map(formula => (
          <FormulaCard key={formula.id} formula={formula} isFavorite={favorites.includes(formula.id)} onToggleFav={toggleFav}
            isExpanded={expanded.includes(formula.id)} onToggleExpand={toggleExpand} />
        ))}
        {filtered.length === 0 && (
          <div className="card p-8 text-center text-[var(--muted-foreground)] text-sm">No formulas match your filters.</div>
        )}
      </div>
    </div>
  );
}

function FormulaCard({ formula, isFavorite, onToggleFav, isExpanded, onToggleExpand }: {
  formula: Formula; isFavorite: boolean; onToggleFav: (id: string) => void;
  isExpanded: boolean; onToggleExpand: (id: string) => void;
}) {
  const color = subjectColors[formula.subject];

  return (
    <div className="card overflow-hidden">
      <div className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap mb-2">
              <span className="badge" style={{ background: color + '20', color }}>{formula.chapter}</span>
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className={`w-1.5 h-1.5 rounded-sm`} style={{ background: i < formula.mainRelevance ? color : 'var(--border)' }} title={`JEE Main relevance: ${formula.mainRelevance}/5`} />
                ))}
                <span className="text-[10px] text-[var(--muted-foreground)] ml-1">Main</span>
              </div>
            </div>
            <h3 className="font-display font-600 text-[var(--foreground)] mb-2">{formula.name}</h3>
            {/* Formula display */}
            <div className="font-mono text-base px-4 py-3 rounded-lg text-center" style={{ background: color + '10', color, border: `1px solid ${color}25`, fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace' }}>
              {formula.formula}
            </div>
          </div>
          <div className="flex flex-col items-end gap-2 flex-shrink-0">
            <button onClick={() => onToggleFav(formula.id)} className={`transition-all hover:scale-110 ${isFavorite ? 'text-amber-400' : 'text-[var(--muted-foreground)]'}`}>
              <Star size={16} fill={isFavorite ? 'currentColor' : 'none'} />
            </button>
            {formula.hasGraph && (
              <span className="badge text-[9px]" style={{ background: '#8b5cf620', color: '#8b5cf6' }}>Graph</span>
            )}
          </div>
        </div>

        {/* Variables row */}
        <div className="flex flex-wrap gap-1.5 mt-3">
          {formula.variables.slice(0, 4).map(v => (
            <span key={v.symbol} className="badge" style={{ background: 'var(--secondary)', color: 'var(--muted-foreground)' }}>
              <span style={{ color }}>{v.symbol}</span> = {v.meaning}{v.unit ? ` (${v.unit})` : ''}
            </span>
          ))}
        </div>

        <button onClick={() => onToggleExpand(formula.id)} className="mt-3 flex items-center gap-1.5 text-xs text-[var(--muted-foreground)] hover:text-[var(--foreground)] transition-colors">
          {isExpanded ? <ChevronDown size={13} /> : <ChevronRight size={13} />}
          {isExpanded ? 'Less details' : 'Conditions, traps & derivation'}
        </button>
      </div>

      {isExpanded && (
        <div className="border-t border-[var(--border)] bg-[var(--secondary)] p-4 space-y-3">
          {/* Conditions */}
          <div>
            <div className="text-xs font-600 text-[var(--foreground)] mb-1.5 flex items-center gap-1.5">
              <BookOpen size={12} /> Conditions & Validity
            </div>
            <div className="space-y-1">
              {formula.conditions.map((c, i) => (
                <div key={i} className="text-xs text-[var(--muted-foreground)] flex items-start gap-2">
                  <span className="text-emerald-400 flex-shrink-0 mt-0.5">✓</span>{c}
                </div>
              ))}
            </div>
          </div>

          {/* Traps */}
          <div>
            <div className="text-xs font-600 text-[var(--foreground)] mb-1.5 flex items-center gap-1.5">
              <AlertTriangle size={12} className="text-amber-400" /> Common Traps & Mistakes
            </div>
            <div className="space-y-1">
              {formula.traps.map((t, i) => (
                <div key={i} className="text-xs text-amber-400/80 flex items-start gap-2">
                  <span className="flex-shrink-0 mt-0.5">⚠</span>{t}
                </div>
              ))}
            </div>
          </div>

          {/* Derivation */}
          <div>
            <div className="text-xs font-600 text-[var(--foreground)] mb-1.5 flex items-center gap-1.5">
              <TrendingUp size={12} /> Quick Derivation
            </div>
            <div className="text-xs text-[var(--muted-foreground)] bg-[var(--muted)] p-2.5 rounded-lg leading-relaxed">
              {formula.derivation}
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-2 pt-1">
            <button className="btn-secondary text-xs py-1.5 px-3" onClick={()=>alert(`Open Practice and filter for ${formula.chapter}`)}>Practice Problems</button>
            <button className="btn-secondary text-xs py-1.5 px-3" onClick={()=>{addRevision({title:`Revise formula: ${formula.name}`,subject:formula.subject,chapter:formula.chapter,dueAt:new Date(Date.now()+86400000).toISOString()});alert('Formula added to revision.')}}>Add to Revision</button>
            <button className="btn-secondary text-xs py-1.5 px-3" onClick={()=>alert('Personal notes can be added when persistent resource notes are connected.')}>Add Note</button>
          </div>
        </div>
      )}
    </div>
  );
}
