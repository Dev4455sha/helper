import { useState } from 'react';
import { ShieldCheck, Mail, Lock, UserRound, GraduationCap } from 'lucide-react';
import { login, signUp } from '../lib/appStore';

export default function AuthGate({ onAuth }: { onAuth: () => void }) {
  const [mode,setMode]=useState<'login'|'signup'>('login'); const [name,setName]=useState(''); const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [className,setClassName]=useState('Class 12'); const [year,setYear]=useState(2027); const [error,setError]=useState(''); const [busy,setBusy]=useState(false);
  async function submit(e:React.FormEvent){e.preventDefault();setError('');setBusy(true);try{if(mode==='signup')await signUp(name,email,password,className,year);else await login(email,password);onAuth();}catch(err){setError(err instanceof Error?err.message:'Authentication failed.');}finally{setBusy(false);}}
  return <div className="min-h-screen flex items-center justify-center p-6" style={{background:'radial-gradient(circle at 20% 10%,#1f2548 0,#0a0d12 45%)'}}>
    <div className="w-full max-w-md card p-7">
      <div className="flex items-center gap-3 mb-7"><div className="w-10 h-10 rounded-xl bg-[var(--primary)] flex items-center justify-center"><GraduationCap size={20}/></div><div><div className="font-display font-700 text-lg">JEE AI Helper</div><div className="text-xs text-[var(--muted-foreground)]">Secure student workspace</div></div></div>
      <div className="flex gap-2 mb-5"><button className={`tab-btn flex-1 ${mode==='login'?'active':''}`} onClick={()=>setMode('login')}>Login</button><button className={`tab-btn flex-1 ${mode==='signup'?'active':''}`} onClick={()=>setMode('signup')}>Sign up</button></div>
      <form onSubmit={submit} className="space-y-3">
        {mode==='signup'&&<label className="block"><span className="label">Name</span><input value={name} onChange={e=>setName(e.target.value)} className="input-field" placeholder="Your name" required/></label>}
        <label className="block"><span className="label">Email</span><div className="relative"><Mail className="input-icon" size={16}/><input type="email" value={email} onChange={e=>setEmail(e.target.value)} className="input-field pl-9" placeholder="you@example.com" required/></div></label>
        <label className="block"><span className="label">Password</span><div className="relative"><Lock className="input-icon" size={16}/><input type="password" value={password} onChange={e=>setPassword(e.target.value)} className="input-field pl-9" minLength={8} placeholder="At least 8 characters" required/></div></label>
        {mode==='signup'&&<div className="grid grid-cols-2 gap-3"><label><span className="label">Class</span><select className="input-field" value={className} onChange={e=>setClassName(e.target.value)}><option>Class 11</option><option>Class 12</option><option>Dropper</option></select></label><label><span className="label">Target year</span><input className="input-field" type="number" min={2026} max={2035} value={year} onChange={e=>setYear(Number(e.target.value))}/></label></div>}
        {error&&<div className="text-xs text-red-300 bg-red-500/10 border border-red-500/20 rounded-lg p-3">{error}</div>}
        <button disabled={busy} className="btn-primary w-full py-2.5 disabled:opacity-50">{busy?'Please wait…':mode==='login'?'Login':'Create account'}</button>
      </form>
      <div className="mt-5 text-[11px] text-[var(--muted-foreground)] flex gap-2"><ShieldCheck size={16} className="text-emerald-400 flex-shrink-0"/><span>Development authentication uses PBKDF2 locally. For production, connect server-side auth/database with row-level security; never store API secrets in the browser.</span></div>
    </div>
  </div>;
}
