export type SubjectKey = 'physics' | 'chemistry' | 'math';
export type StatusKey = 'not_started' | 'learning' | 'practicing' | 'strong' | 'revision' | 'mastered';

export interface Topic {
  id: string;
  name: string;
  subtopics: string[];
  status: StatusKey;
  accuracy: number;
  questionsAttempted: number;
  questionsTotal: number;
  lastStudied: string;
  pyqCount: number;
  weightage: number; // JEE weightage in %
}

export interface Chapter {
  id: string;
  name: string;
  topics: Topic[];
  status: StatusKey;
  accuracy: number;
  progress: number;
  weakConcepts: string[];
  nextRevision: string;
  pyqCount: number;
  weightage: number;
}

export interface Subject {
  key: SubjectKey;
  name: string;
  color: string;
  chapters: Chapter[];
  overallProgress: number;
  accuracy: number;
  pyqAttempted: number;
  totalPYQs: number;
}

export const SYLLABUS: Subject[] = [
  {
    key: 'physics',
    name: 'Physics',
    color: '#3b82f6',
    overallProgress: 62,
    accuracy: 71,
    pyqAttempted: 143,
    totalPYQs: 380,
    chapters: [
      {
        id: 'ph1', name: 'Kinematics', status: 'mastered', accuracy: 88, progress: 95,
        weightage: 5, pyqCount: 24,
        weakConcepts: ['Relative motion in 2D', 'Projectile on inclined plane'],
        nextRevision: '2025-01-28',
        topics: [
          { id: 'ph1t1', name: 'Motion in 1D', subtopics: ['Displacement & Velocity', 'Acceleration', 'Graphs of motion', 'Free fall', 'Motion with variable acceleration'], status: 'mastered', accuracy: 92, questionsAttempted: 45, questionsTotal: 50, lastStudied: '2025-01-18', pyqCount: 8, weightage: 2 },
          { id: 'ph1t2', name: 'Motion in 2D', subtopics: ['Vectors', 'Projectile motion', 'Circular motion', 'Relative velocity', 'River-boat problems'], status: 'strong', accuracy: 85, questionsAttempted: 38, questionsTotal: 45, lastStudied: '2025-01-17', pyqCount: 10, weightage: 2 },
          { id: 'ph1t3', name: 'Projectile Motion', subtopics: ['Horizontal projectile', 'Oblique projectile', 'Range & Height', 'Projectile on incline'], status: 'strong', accuracy: 83, questionsAttempted: 30, questionsTotal: 35, lastStudied: '2025-01-16', pyqCount: 6, weightage: 1 },
        ]
      },
      {
        id: 'ph2', name: 'Laws of Motion', status: 'strong', accuracy: 79, progress: 82,
        weightage: 8, pyqCount: 35,
        weakConcepts: ['Friction on wedge systems', 'Pseudo force problems'],
        nextRevision: '2025-01-30',
        topics: [
          { id: 'ph2t1', name: "Newton's Laws", subtopics: ["Newton's 1st Law", "Newton's 2nd Law", "Newton's 3rd Law", 'Action-Reaction pairs'], status: 'mastered', accuracy: 90, questionsAttempted: 40, questionsTotal: 42, lastStudied: '2025-01-15', pyqCount: 12, weightage: 3 },
          { id: 'ph2t2', name: 'Friction', subtopics: ['Static friction', 'Kinetic friction', 'Angle of friction', 'Friction on incline', 'Ladder problems'], status: 'practicing', accuracy: 68, questionsAttempted: 28, questionsTotal: 45, lastStudied: '2025-01-14', pyqCount: 14, weightage: 3 },
          { id: 'ph2t3', name: 'Pulley Systems', subtopics: ['Atwood machine', 'Connected bodies', 'Variable mass systems'], status: 'learning', accuracy: 61, questionsAttempted: 18, questionsTotal: 30, lastStudied: '2025-01-13', pyqCount: 9, weightage: 2 },
        ]
      },
      {
        id: 'ph3', name: 'Work, Energy & Power', status: 'practicing', accuracy: 74, progress: 70,
        weightage: 7, pyqCount: 30,
        weakConcepts: ['Variable force work', 'Collision energy analysis'],
        nextRevision: '2025-02-01',
        topics: [
          { id: 'ph3t1', name: 'Work & Energy', subtopics: ['Work done by constant force', 'Work done by variable force', 'Kinetic Energy theorem', 'Spring force work'], status: 'strong', accuracy: 80, questionsAttempted: 35, questionsTotal: 40, lastStudied: '2025-01-12', pyqCount: 10, weightage: 3 },
          { id: 'ph3t2', name: 'Potential Energy', subtopics: ['Gravitational PE', 'Spring PE', 'Conservative forces', 'Energy diagrams'], status: 'practicing', accuracy: 72, questionsAttempted: 25, questionsTotal: 35, lastStudied: '2025-01-11', pyqCount: 10, weightage: 2 },
          { id: 'ph3t3', name: 'Collisions', subtopics: ['Elastic collision', 'Inelastic collision', 'Coefficient of restitution', '2D collisions'], status: 'learning', accuracy: 65, questionsAttempted: 20, questionsTotal: 30, lastStudied: '2025-01-10', pyqCount: 10, weightage: 2 },
        ]
      },
      {
        id: 'ph4', name: 'Rotational Motion', status: 'learning', accuracy: 58, progress: 45,
        weightage: 10, pyqCount: 42,
        weakConcepts: ['Moment of inertia complex shapes', 'Rolling with slipping', 'Angular momentum conservation'],
        nextRevision: '2025-02-03',
        topics: [
          { id: 'ph4t1', name: 'Rigid Body Kinematics', subtopics: ['Angular velocity & acceleration', 'Rolling without slipping', 'Angular kinematics equations'], status: 'learning', accuracy: 60, questionsAttempted: 22, questionsTotal: 38, lastStudied: '2025-01-09', pyqCount: 12, weightage: 3 },
          { id: 'ph4t2', name: 'Moment of Inertia', subtopics: ['MI of basic shapes', 'Parallel axis theorem', 'Perpendicular axis theorem', 'MI calculations'], status: 'learning', accuracy: 55, questionsAttempted: 18, questionsTotal: 35, lastStudied: '2025-01-08', pyqCount: 14, weightage: 4 },
          { id: 'ph4t3', name: 'Torque & Angular Momentum', subtopics: ['Torque calculations', 'Angular momentum', 'Conservation laws', 'Rolling problems'], status: 'not_started', accuracy: 0, questionsAttempted: 0, questionsTotal: 30, lastStudied: '—', pyqCount: 16, weightage: 3 },
        ]
      },
      {
        id: 'ph5', name: 'Gravitation', status: 'strong', accuracy: 82, progress: 85,
        weightage: 5, pyqCount: 22,
        weakConcepts: ['Orbital velocity derivation', 'Escape velocity with air resistance'],
        nextRevision: '2025-02-05',
        topics: [
          { id: 'ph5t1', name: "Newton's Law of Gravitation", subtopics: ['Gravitational force', 'G constant', 'Superposition principle'], status: 'mastered', accuracy: 88, questionsAttempted: 20, questionsTotal: 22, lastStudied: '2025-01-07', pyqCount: 6, weightage: 1 },
          { id: 'ph5t2', name: 'Orbital Motion', subtopics: ['Orbital velocity', 'Escape velocity', "Kepler's laws", 'Geostationary orbit', 'Binding energy'], status: 'strong', accuracy: 78, questionsAttempted: 28, questionsTotal: 35, lastStudied: '2025-01-06', pyqCount: 16, weightage: 4 },
        ]
      },
      {
        id: 'ph6', name: 'Electrostatics', status: 'practicing', accuracy: 70, progress: 60,
        weightage: 9, pyqCount: 38,
        weakConcepts: ['Gauss law application', 'Potential of complex configurations'],
        nextRevision: '2025-02-08',
        topics: [
          { id: 'ph6t1', name: "Coulomb's Law & Electric Field", subtopics: ["Coulomb's law", 'Electric field of point charge', 'Superposition', 'Field of dipole', 'Field lines'], status: 'strong', accuracy: 78, questionsAttempted: 32, questionsTotal: 38, lastStudied: '2025-01-05', pyqCount: 12, weightage: 3 },
          { id: 'ph6t2', name: "Gauss's Law", subtopics: ['Flux', "Gauss's theorem", 'Field due to infinite sheet', 'Field inside conductor', 'Spherical shells'], status: 'practicing', accuracy: 65, questionsAttempted: 22, questionsTotal: 35, lastStudied: '2025-01-04', pyqCount: 14, weightage: 3 },
          { id: 'ph6t3', name: 'Electric Potential', subtopics: ['Potential due to point charge', 'Potential of system', 'Equipotential surfaces', 'Potential energy'], status: 'learning', accuracy: 62, questionsAttempted: 18, questionsTotal: 30, lastStudied: '2025-01-03', pyqCount: 12, weightage: 3 },
        ]
      },
      {
        id: 'ph7', name: 'Current Electricity', status: 'practicing', accuracy: 68, progress: 55,
        weightage: 8, pyqCount: 34,
        weakConcepts: ["Wheatstone bridge", 'RC transients'],
        nextRevision: '2025-02-10',
        topics: [
          { id: 'ph7t1', name: "Ohm's Law & Resistance", subtopics: ['Current density', 'Drift velocity', 'Resistivity', 'Temperature dependence', 'Series-parallel resistors'], status: 'strong', accuracy: 80, questionsAttempted: 30, questionsTotal: 35, lastStudied: '2024-12-28', pyqCount: 10, weightage: 3 },
          { id: 'ph7t2', name: "Kirchhoff's Laws", subtopics: ['KCL', 'KVL', 'Network analysis', 'Wheatstone bridge', 'Potentiometer'], status: 'practicing', accuracy: 65, questionsAttempted: 22, questionsTotal: 35, lastStudied: '2024-12-26', pyqCount: 14, weightage: 3 },
          { id: 'ph7t3', name: 'EMF & Cells', subtopics: ['Internal resistance', 'Cells in series/parallel', 'Maximum power transfer', 'EMF measurement'], status: 'learning', accuracy: 58, questionsAttempted: 15, questionsTotal: 28, lastStudied: '2024-12-24', pyqCount: 10, weightage: 2 },
        ]
      },
      {
        id: 'ph8', name: 'Optics', status: 'learning', accuracy: 61, progress: 42,
        weightage: 8, pyqCount: 32,
        weakConcepts: ['Wave optics YDSE path difference', 'Diffraction patterns'],
        nextRevision: '2025-02-12',
        topics: [
          { id: 'ph8t1', name: 'Ray Optics', subtopics: ['Reflection', 'Refraction', 'Snell\'s law', 'Total internal reflection', 'Prism', 'Lenses', 'Mirrors', 'Optical instruments'], status: 'practicing', accuracy: 70, questionsAttempted: 28, questionsTotal: 38, lastStudied: '2024-12-22', pyqCount: 16, weightage: 4 },
          { id: 'ph8t2', name: 'Wave Optics', subtopics: ['Huygens principle', 'YDSE', 'Diffraction', 'Polarization', 'Brewster\'s law'], status: 'learning', accuracy: 52, questionsAttempted: 14, questionsTotal: 30, lastStudied: '2024-12-20', pyqCount: 16, weightage: 4 },
        ]
      },
      {
        id: 'ph9', name: 'Modern Physics', status: 'not_started', accuracy: 0, progress: 15,
        weightage: 7, pyqCount: 28,
        weakConcepts: [],
        nextRevision: '2025-02-15',
        topics: [
          { id: 'ph9t1', name: 'Photoelectric Effect', subtopics: ['Photon model', 'Threshold frequency', 'Stopping potential', 'Einstein equation', 'Applications'], status: 'not_started', accuracy: 0, questionsAttempted: 0, questionsTotal: 25, lastStudied: '—', pyqCount: 10, weightage: 3 },
          { id: 'ph9t2', name: 'Nuclear Physics', subtopics: ['Nuclear structure', 'Radioactivity', 'Alpha/Beta/Gamma decay', 'Half-life', 'Nuclear fission & fusion', 'Q-value'], status: 'not_started', accuracy: 0, questionsAttempted: 0, questionsTotal: 28, lastStudied: '—', pyqCount: 18, weightage: 4 },
        ]
      },
    ]
  },
  {
    key: 'chemistry',
    name: 'Chemistry',
    color: '#10b981',
    overallProgress: 55,
    accuracy: 68,
    pyqAttempted: 112,
    totalPYQs: 360,
    chapters: [
      {
        id: 'ch1', name: 'Mole Concept & Stoichiometry', status: 'mastered', accuracy: 91, progress: 96,
        weightage: 6, pyqCount: 20,
        weakConcepts: ['Back titration', 'Limiting reagent in multi-step'],
        nextRevision: '2025-01-29',
        topics: [
          { id: 'ch1t1', name: 'Mole Concept', subtopics: ['Mole definition', 'Avogadro number', 'Molar mass', 'Gram atoms & molecules', 'Number-mass interconversion'], status: 'mastered', accuracy: 94, questionsAttempted: 40, questionsTotal: 42, lastStudied: '2025-01-15', pyqCount: 8, weightage: 3 },
          { id: 'ch1t2', name: 'Stoichiometry', subtopics: ['Balancing equations', 'Limiting reagent', 'Percentage yield', 'Back titration', 'Volumetric analysis'], status: 'strong', accuracy: 88, questionsAttempted: 35, questionsTotal: 40, lastStudied: '2025-01-14', pyqCount: 12, weightage: 3 },
        ]
      },
      {
        id: 'ch2', name: 'Atomic Structure', status: 'strong', accuracy: 82, progress: 85,
        weightage: 5, pyqCount: 18,
        weakConcepts: ['Quantum numbers borderline cases', 'Zeeman effect'],
        nextRevision: '2025-02-01',
        topics: [
          { id: 'ch2t1', name: 'Bohr Model', subtopics: ['Postulates', 'Energy levels', 'Spectral series', 'Hydrogen spectrum', 'Limitations'], status: 'mastered', accuracy: 88, questionsAttempted: 30, questionsTotal: 32, lastStudied: '2025-01-12', pyqCount: 8, weightage: 2 },
          { id: 'ch2t2', name: 'Quantum Mechanics', subtopics: ['Heisenberg uncertainty', 'de Broglie wavelength', 'Quantum numbers', 'Orbitals', 'Electronic config'], status: 'strong', accuracy: 76, questionsAttempted: 25, questionsTotal: 32, lastStudied: '2025-01-11', pyqCount: 10, weightage: 3 },
        ]
      },
      {
        id: 'ch3', name: 'Chemical Bonding', status: 'practicing', accuracy: 73, progress: 68,
        weightage: 8, pyqCount: 28,
        weakConcepts: ['Molecular orbital theory ordering', 'VSEPR exceptions'],
        nextRevision: '2025-02-04',
        topics: [
          { id: 'ch3t1', name: 'Ionic & Covalent Bonding', subtopics: ['Ionic bond', 'Lattice energy', 'Born-Haber cycle', 'Covalent bond', 'Bond order', 'Bond length & energy'], status: 'strong', accuracy: 80, questionsAttempted: 32, questionsTotal: 38, lastStudied: '2025-01-09', pyqCount: 10, weightage: 3 },
          { id: 'ch3t2', name: 'VSEPR & Hybridization', subtopics: ['VSEPR theory', 'Molecular geometry', 'Hybridization sp sp2 sp3', 'Bond angles', 'Dipole moment'], status: 'practicing', accuracy: 70, questionsAttempted: 25, questionsTotal: 35, lastStudied: '2025-01-08', pyqCount: 10, weightage: 3 },
          { id: 'ch3t3', name: 'MOT', subtopics: ['Bonding/Antibonding orbitals', 'MO configurations', 'Bond order from MOT', 'Magnetic properties'], status: 'learning', accuracy: 62, questionsAttempted: 15, questionsTotal: 28, lastStudied: '2025-01-07', pyqCount: 8, weightage: 2 },
        ]
      },
      {
        id: 'ch4', name: 'Chemical Equilibrium', status: 'practicing', accuracy: 69, progress: 58,
        weightage: 7, pyqCount: 24,
        weakConcepts: ['Kp-Kc conversion', 'Le Chatelier complex scenarios'],
        nextRevision: '2025-02-06',
        topics: [
          { id: 'ch4t1', name: 'Equilibrium Constants', subtopics: ['Kc and Kp', 'Relationship Kp-Kc', 'Degree of dissociation', 'Q vs K', 'Equilibrium calculations'], status: 'practicing', accuracy: 70, questionsAttempted: 25, questionsTotal: 35, lastStudied: '2025-01-05', pyqCount: 12, weightage: 4 },
          { id: 'ch4t2', name: "Le Chatelier's Principle", subtopics: ['Effect of temperature', 'Effect of pressure', 'Effect of concentration', 'Inert gas addition', 'Applications'], status: 'learning', accuracy: 65, questionsAttempted: 18, questionsTotal: 28, lastStudied: '2025-01-04', pyqCount: 12, weightage: 3 },
        ]
      },
      {
        id: 'ch5', name: 'Organic Chemistry - Basics', status: 'strong', accuracy: 77, progress: 75,
        weightage: 9, pyqCount: 32,
        weakConcepts: ['Hyperconjugation in stability', 'Electrophilic aromatic substitution directing effects'],
        nextRevision: '2025-02-08',
        topics: [
          { id: 'ch5t1', name: 'IUPAC Nomenclature', subtopics: ['Naming alkanes', 'Naming alkenes & alkynes', 'Functional groups', 'Cyclic compounds', 'Complex systems'], status: 'strong', accuracy: 82, questionsAttempted: 30, questionsTotal: 35, lastStudied: '2025-01-03', pyqCount: 8, weightage: 2 },
          { id: 'ch5t2', name: 'Reaction Mechanisms', subtopics: ['Inductive effect', 'Resonance', 'Hyperconjugation', 'Carbocation stability', 'Carbanion stability', 'Free radical'], status: 'practicing', accuracy: 72, questionsAttempted: 28, questionsTotal: 40, lastStudied: '2025-01-02', pyqCount: 16, weightage: 4 },
          { id: 'ch5t3', name: 'Isomerism', subtopics: ['Structural isomers', 'Geometrical isomers', 'Optical isomers', 'Conformations', 'Tautomers'], status: 'practicing', accuracy: 68, questionsAttempted: 22, questionsTotal: 32, lastStudied: '2025-01-01', pyqCount: 8, weightage: 3 },
        ]
      },
      {
        id: 'ch6', name: 'Hydrocarbons & Reactions', status: 'learning', accuracy: 63, progress: 48,
        weightage: 8, pyqCount: 28,
        weakConcepts: ['Diels-Alder conditions', 'Markovnikov in complex alkenes'],
        nextRevision: '2025-02-10',
        topics: [
          { id: 'ch6t1', name: 'Alkanes & Alkenes', subtopics: ['Preparation of alkanes', 'Reactions of alkenes', 'Markovnikov rule', 'Ozonolysis', 'Hydrogenation'], status: 'learning', accuracy: 65, questionsAttempted: 20, questionsTotal: 32, lastStudied: '2024-12-28', pyqCount: 10, weightage: 3 },
          { id: 'ch6t2', name: 'Alkynes & Benzene', subtopics: ['Preparation of alkynes', 'Acidic character', 'Benzene structure', 'EAS reactions', 'Substituent effects'], status: 'learning', accuracy: 60, questionsAttempted: 15, questionsTotal: 30, lastStudied: '2024-12-25', pyqCount: 18, weightage: 5 },
        ]
      },
      {
        id: 'ch7', name: 'Electrochemistry', status: 'not_started', accuracy: 0, progress: 10,
        weightage: 6, pyqCount: 22,
        weakConcepts: [],
        nextRevision: '2025-02-14',
        topics: [
          { id: 'ch7t1', name: 'Electrolytic Cells', subtopics: ['Faraday\'s laws', 'Electrolysis calculations', 'Products of electrolysis', 'Electroplating'], status: 'not_started', accuracy: 0, questionsAttempted: 0, questionsTotal: 25, lastStudied: '—', pyqCount: 10, weightage: 3 },
          { id: 'ch7t2', name: 'Galvanic Cells', subtopics: ['EMF of cell', 'Nernst equation', 'Standard potentials', 'Batteries'], status: 'not_started', accuracy: 0, questionsAttempted: 0, questionsTotal: 25, lastStudied: '—', pyqCount: 12, weightage: 3 },
        ]
      },
      {
        id: 'ch8', name: 'p-Block Elements', status: 'learning', accuracy: 59, progress: 38,
        weightage: 8, pyqCount: 30,
        weakConcepts: ['Phosphorus oxyacids structures', 'Halogen interhalogen compounds'],
        nextRevision: '2025-02-16',
        topics: [
          { id: 'ch8t1', name: 'Group 13 & 14', subtopics: ['Boron chemistry', 'Aluminium compounds', 'Carbon allotropes', 'Silicon compounds', 'Tin & Lead'], status: 'learning', accuracy: 62, questionsAttempted: 18, questionsTotal: 30, lastStudied: '2024-12-22', pyqCount: 10, weightage: 3 },
          { id: 'ch8t2', name: 'Group 15, 16, 17', subtopics: ['Nitrogen oxides & acids', 'Phosphorus compounds', 'Sulphur oxyacids', 'Halogens', 'Interhalogen compounds'], status: 'learning', accuracy: 56, questionsAttempted: 14, questionsTotal: 32, lastStudied: '2024-12-20', pyqCount: 20, weightage: 5 },
        ]
      },
    ]
  },
  {
    key: 'math',
    name: 'Mathematics',
    color: '#f59e0b',
    overallProgress: 58,
    accuracy: 66,
    pyqAttempted: 128,
    totalPYQs: 420,
    chapters: [
      {
        id: 'ma1', name: 'Quadratic Equations', status: 'strong', accuracy: 83, progress: 88,
        weightage: 5, pyqCount: 22,
        weakConcepts: ['Nature of roots with parameters', 'Location of roots conditions'],
        nextRevision: '2025-01-30',
        topics: [
          { id: 'ma1t1', name: 'Quadratic Formula & Roots', subtopics: ['Discriminant', 'Sum & Product of roots', 'Nature of roots', 'Common roots', 'Symmetric functions'], status: 'strong', accuracy: 86, questionsAttempted: 35, questionsTotal: 40, lastStudied: '2025-01-16', pyqCount: 10, weightage: 2 },
          { id: 'ma1t2', name: 'Inequalities & Location', subtopics: ['Sign of quadratic', 'Intervals', 'Location of roots', 'Parametric conditions', 'Wavy curve method'], status: 'practicing', accuracy: 78, questionsAttempted: 28, questionsTotal: 35, lastStudied: '2025-01-15', pyqCount: 12, weightage: 3 },
        ]
      },
      {
        id: 'ma2', name: 'Complex Numbers', status: 'strong', accuracy: 79, progress: 80,
        weightage: 6, pyqCount: 25,
        weakConcepts: ['Rotation formula applications', 'nth roots of complex numbers'],
        nextRevision: '2025-02-02',
        topics: [
          { id: 'ma2t1', name: 'Algebra of Complex Numbers', subtopics: ['Modulus & Argument', 'Conjugate', 'Polar form', 'Euler form', 'De Moivre theorem'], status: 'strong', accuracy: 82, questionsAttempted: 30, questionsTotal: 35, lastStudied: '2025-01-13', pyqCount: 10, weightage: 3 },
          { id: 'ma2t2', name: 'Geometry of Complex Numbers', subtopics: ['Loci in complex plane', 'Rotation formula', 'Triangle & circle conditions', 'nth roots of unity'], status: 'practicing', accuracy: 72, questionsAttempted: 22, questionsTotal: 32, lastStudied: '2025-01-12', pyqCount: 15, weightage: 3 },
        ]
      },
      {
        id: 'ma3', name: 'Sequences & Series', status: 'practicing', accuracy: 72, progress: 65,
        weightage: 5, pyqCount: 20,
        weakConcepts: ['AGP sum formula', 'Telescoping series'],
        nextRevision: '2025-02-04',
        topics: [
          { id: 'ma3t1', name: 'AP & GP', subtopics: ['AP nth term & sum', 'GP nth term & sum', 'Sum to infinity of GP', 'Properties of AP/GP'], status: 'strong', accuracy: 80, questionsAttempted: 30, questionsTotal: 35, lastStudied: '2025-01-10', pyqCount: 8, weightage: 2 },
          { id: 'ma3t2', name: 'Special Series & HP', subtopics: ['AM-GM inequality', 'Harmonic Progression', 'AGP sum', 'Natural number sums', 'Telescoping series'], status: 'practicing', accuracy: 64, questionsAttempted: 20, questionsTotal: 32, lastStudied: '2025-01-09', pyqCount: 12, weightage: 3 },
        ]
      },
      {
        id: 'ma4', name: 'Trigonometry', status: 'strong', accuracy: 81, progress: 82,
        weightage: 8, pyqCount: 32,
        weakConcepts: ['General solution with multiple angles', 'Trigonometric equations parametric'],
        nextRevision: '2025-02-06',
        topics: [
          { id: 'ma4t1', name: 'Trigonometric Ratios & Identities', subtopics: ['Compound angles', 'Double & half angles', 'Product to sum', 'Sum to product', 'Conditional identities'], status: 'mastered', accuracy: 88, questionsAttempted: 40, questionsTotal: 42, lastStudied: '2025-01-08', pyqCount: 12, weightage: 3 },
          { id: 'ma4t2', name: 'Trigonometric Equations', subtopics: ['General solutions', 'Principal values', 'Multiple angle equations', 'Simultaneous equations'], status: 'strong', accuracy: 76, questionsAttempted: 28, questionsTotal: 35, lastStudied: '2025-01-07', pyqCount: 10, weightage: 3 },
          { id: 'ma4t3', name: 'Inverse Trigonometry', subtopics: ['Domain & Range', 'Properties of inverse trig', 'Composition of functions', 'Equations & inequalities'], status: 'practicing', accuracy: 72, questionsAttempted: 22, questionsTotal: 30, lastStudied: '2025-01-06', pyqCount: 10, weightage: 2 },
        ]
      },
      {
        id: 'ma5', name: 'Coordinate Geometry', status: 'practicing', accuracy: 70, progress: 62,
        weightage: 12, pyqCount: 45,
        weakConcepts: ['Radical axis of circles', 'Normals to parabola', 'Chord of contact ellipse'],
        nextRevision: '2025-02-08',
        topics: [
          { id: 'ma5t1', name: 'Straight Lines', subtopics: ['Distance formula', 'Section formula', 'Slope', 'Angle between lines', 'Foot of perpendicular', 'Angle bisectors', 'Family of lines'], status: 'strong', accuracy: 82, questionsAttempted: 35, questionsTotal: 40, lastStudied: '2025-01-05', pyqCount: 12, weightage: 3 },
          { id: 'ma5t2', name: 'Circles', subtopics: ['Standard equation', 'Tangent & normal', 'Chord of contact', 'Radical axis', 'Family of circles', 'Common tangents'], status: 'practicing', accuracy: 68, questionsAttempted: 25, questionsTotal: 38, lastStudied: '2025-01-04', pyqCount: 15, weightage: 4 },
          { id: 'ma5t3', name: 'Parabola', subtopics: ['Standard forms', 'Focus & directrix', 'Parametric form', 'Tangent & normal', 'Chord problems', 'Properties'], status: 'practicing', accuracy: 64, questionsAttempted: 20, questionsTotal: 32, lastStudied: '2025-01-03', pyqCount: 10, weightage: 3 },
          { id: 'ma5t4', name: 'Ellipse & Hyperbola', subtopics: ['Ellipse properties', 'Conjugate hyperbola', 'Asymptotes', 'Tangent & normal', 'Locus problems'], status: 'learning', accuracy: 58, questionsAttempted: 15, questionsTotal: 30, lastStudied: '2025-01-02', pyqCount: 8, weightage: 2 },
        ]
      },
      {
        id: 'ma6', name: 'Differential Calculus', status: 'practicing', accuracy: 69, progress: 58,
        weightage: 12, pyqCount: 48,
        weakConcepts: ['L\'Hopital repeated application', 'Differentiability at corners', 'Rolle\'s theorem conditions'],
        nextRevision: '2025-02-10',
        topics: [
          { id: 'ma6t1', name: 'Limits', subtopics: ['Algebra of limits', 'L\'Hopital rule', '0/0 and ∞/∞ forms', 'Sandwich theorem', 'Standard limits', 'Continuity'], status: 'strong', accuracy: 78, questionsAttempted: 30, questionsTotal: 38, lastStudied: '2024-12-28', pyqCount: 14, weightage: 4 },
          { id: 'ma6t2', name: 'Derivatives', subtopics: ['First principles', 'Chain rule', 'Product & quotient rule', 'Implicit differentiation', 'Parametric derivatives', 'Higher order derivatives'], status: 'practicing', accuracy: 72, questionsAttempted: 28, questionsTotal: 38, lastStudied: '2024-12-26', pyqCount: 14, weightage: 4 },
          { id: 'ma6t3', name: 'Applications of Derivatives', subtopics: ['Monotonicity', 'Maxima & Minima', 'Tangent & Normal', 'Rate of change', 'Mean value theorems', 'Curve sketching'], status: 'practicing', accuracy: 65, questionsAttempted: 22, questionsTotal: 35, lastStudied: '2024-12-24', pyqCount: 20, weightage: 4 },
        ]
      },
      {
        id: 'ma7', name: 'Integral Calculus', status: 'learning', accuracy: 61, progress: 45,
        weightage: 12, pyqCount: 48,
        weakConcepts: ['Integration by parts repeated', 'Reduction formulas', 'Area between curves'],
        nextRevision: '2025-02-14',
        topics: [
          { id: 'ma7t1', name: 'Indefinite Integration', subtopics: ['Standard integrals', 'Substitution method', 'Integration by parts', 'Partial fractions', 'Special forms', 'Trigonometric integrals'], status: 'learning', accuracy: 64, questionsAttempted: 25, questionsTotal: 40, lastStudied: '2024-12-22', pyqCount: 16, weightage: 4 },
          { id: 'ma7t2', name: 'Definite Integration', subtopics: ['Newton-Leibniz theorem', 'Properties of definite integrals', 'Walli\'s formula', 'Gamma function', 'King\'s property', 'Periodic functions'], status: 'learning', accuracy: 60, questionsAttempted: 18, questionsTotal: 35, lastStudied: '2024-12-20', pyqCount: 18, weightage: 4 },
          { id: 'ma7t3', name: 'Area & Differential Equations', subtopics: ['Area under curves', 'Area between curves', 'Variable separable', 'Homogeneous DE', 'Linear DE', 'Bernoulli DE'], status: 'not_started', accuracy: 0, questionsAttempted: 0, questionsTotal: 30, lastStudied: '—', pyqCount: 14, weightage: 4 },
        ]
      },
      {
        id: 'ma8', name: 'Vectors & 3D Geometry', status: 'learning', accuracy: 64, progress: 48,
        weightage: 8, pyqCount: 30,
        weakConcepts: ['Skew lines distance', 'Plane through intersection of planes'],
        nextRevision: '2025-02-16',
        topics: [
          { id: 'ma8t1', name: 'Vectors', subtopics: ['Vector operations', 'Dot product', 'Cross product', 'Scalar triple product', 'Vector triple product', 'Applications'], status: 'practicing', accuracy: 72, questionsAttempted: 25, questionsTotal: 35, lastStudied: '2024-12-18', pyqCount: 12, weightage: 4 },
          { id: 'ma8t2', name: '3D Geometry', subtopics: ['Direction cosines', 'Equations of line', 'Equations of plane', 'Angle between line & plane', 'Distance formulas', 'Skew lines'], status: 'learning', accuracy: 58, questionsAttempted: 15, questionsTotal: 30, lastStudied: '2024-12-16', pyqCount: 18, weightage: 4 },
        ]
      },
      {
        id: 'ma9', name: 'Permutation & Combination', status: 'strong', accuracy: 80, progress: 82,
        weightage: 5, pyqCount: 20,
        weakConcepts: ['Derangements', 'Multinomial theorem'],
        nextRevision: '2025-02-02',
        topics: [
          { id: 'ma9t1', name: 'Permutations', subtopics: ['Factorial', 'nPr formula', 'Circular permutation', 'Permutations with restrictions', 'Permutations of identical objects'], status: 'strong', accuracy: 82, questionsAttempted: 30, questionsTotal: 35, lastStudied: '2025-01-01', pyqCount: 8, weightage: 2 },
          { id: 'ma9t2', name: 'Combinations & Binomial', subtopics: ['nCr formula', 'Properties of nCr', 'Distribution problems', 'Binomial theorem', 'General term', 'Middle term'], status: 'strong', accuracy: 78, questionsAttempted: 28, questionsTotal: 35, lastStudied: '2024-12-31', pyqCount: 12, weightage: 3 },
        ]
      },
    ]
  }
];

export type QuestionType = 'MCQ' | 'Numerical' | 'Multiple Correct' | 'Integer' | 'Assertion-Reason';
export type Difficulty = 'Easy' | 'Medium' | 'Hard';
export type Source = 'Practice' | 'AI Generated' | 'Custom';

export interface Question {
  id: string;
  subject: SubjectKey;
  chapter: string;
  topic: string;
  type: QuestionType;
  difficulty: Difficulty;
  source: Source;
  question: string;
  options?: string[];
  correctAnswer: string | number | string[];
  solution: string;
  concepts: string[];
  timeLimit: number; // seconds
  averageTime: number;
  successRate: number;
  year?: number;
  tags: string[];
}

export const QUESTIONS: Question[] = [
  {
    id: 'q1',
    subject: 'physics',
    chapter: 'Kinematics',
    topic: 'Projectile Motion',
    type: 'MCQ',
    difficulty: 'Medium',
    source: 'Practice',
    question: 'A ball is projected at an angle of 45° with the horizontal. If the range is R, what is the maximum height attained by the ball?',
    options: ['R/2', 'R/4', 'R/8', 'R'],
    correctAnswer: 'R/4',
    solution: 'For angle θ = 45°, R = u²sin(2θ)/g = u²/g. Maximum height H = u²sin²θ/(2g) = u²/(2·2g) = u²/(4g). Therefore H = R/4.',
    concepts: ['Projectile motion', 'Range formula', 'Maximum height'],
    timeLimit: 120,
    averageTime: 95,
    successRate: 62,
    tags: ['projectile', 'range', 'height', '45 degrees']
  },
  {
    id: 'q2',
    subject: 'physics',
    chapter: 'Laws of Motion',
    topic: 'Friction',
    type: 'Numerical',
    difficulty: 'Hard',
    source: 'Practice',
    question: 'A block of mass 5 kg is placed on an inclined plane making 30° with horizontal. The coefficient of static friction is 0.4 and kinetic friction is 0.3. What is the acceleration of the block (in m/s²)? (Take g = 10 m/s²)',
    correctAnswer: 2.4,
    solution: 'Normal force N = mg cos30° = 5×10×(√3/2) = 43.3 N. Friction force = μk×N = 0.3×43.3 = 13.0 N. Net force = mg sin30° - f = 25 - 13 = 12 N. Acceleration = 12/5 = 2.4 m/s². Note: Check if block slides: mg sin30° = 25 N > μs×N = 17.3 N, so block does slide.',
    concepts: ['Friction', 'Inclined plane', 'Normal force', 'Net force'],
    timeLimit: 180,
    averageTime: 145,
    successRate: 41,
    tags: ['friction', 'inclined plane', 'numerical', 'acceleration']
  },
  {
    id: 'q3',
    subject: 'physics',
    chapter: 'Electrostatics',
    topic: "Gauss's Law",
    type: 'MCQ',
    difficulty: 'Hard',
    source: 'AI Generated',
    question: 'A solid metallic sphere of radius R carries a total charge Q. What is the electric field at a distance r from the center where r < R?',
    options: ['kQ/r²', 'kQr/R³', '0', 'kQ/R²'],
    correctAnswer: '0',
    solution: "Inside a conductor in electrostatic equilibrium, the electric field is zero. All free charges reside on the surface. By Gauss's law, for a Gaussian surface inside the conductor, the enclosed charge is zero, so E = 0.",
    concepts: ['Conductors', "Gauss's law", 'Electrostatic shielding'],
    timeLimit: 90,
    averageTime: 75,
    successRate: 55,
    tags: ["gauss's law", 'conductor', 'electric field', 'inside sphere']
  },
  {
    id: 'q4',
    subject: 'chemistry',
    chapter: 'Mole Concept & Stoichiometry',
    topic: 'Stoichiometry',
    type: 'Numerical',
    difficulty: 'Medium',
    source: 'Practice',
    question: 'How many grams of CaCO₃ are needed to produce 22.4 L of CO₂ at STP according to: CaCO₃ → CaO + CO₂?',
    correctAnswer: 100,
    solution: '22.4 L at STP = 1 mole of CO₂. From stoichiometry, 1 mole CaCO₃ produces 1 mole CO₂. Molar mass of CaCO₃ = 40 + 12 + 48 = 100 g/mol. Therefore, 100 g of CaCO₃ is needed.',
    concepts: ['Mole concept', 'Stoichiometry', 'STP conditions', 'Molar volume'],
    timeLimit: 120,
    averageTime: 88,
    successRate: 71,
    tags: ['mole concept', 'stoichiometry', 'STP', 'CaCO3']
  },
  {
    id: 'q5',
    subject: 'chemistry',
    chapter: 'Chemical Bonding',
    topic: 'VSEPR & Hybridization',
    type: 'Multiple Correct',
    difficulty: 'Hard',
    source: 'AI Generated',
    question: 'Which of the following statements about SF₄ are correct? (Select all that apply)',
    options: [
      'The hybridization of S is sp³d',
      'The geometry is see-saw (disphenoidal)',
      'It has one lone pair on sulfur',
      'The bond angles are exactly 90° and 120°',
      'It is a polar molecule'
    ],
    correctAnswer: ['The hybridization of S is sp³d', 'The geometry is see-saw (disphenoidal)', 'It has one lone pair on sulfur', 'It is a polar molecule'],
    solution: 'SF₄: S has 6 valence electrons, 4 bonds with F, 1 lone pair → 5 electron pairs → sp³d hybridization. VSEPR geometry: see-saw. Lone pair causes distortion so bond angles are not exactly 90° and 120°. Due to asymmetry, SF₄ is polar.',
    concepts: ['VSEPR theory', 'Hybridization', 'Molecular geometry', 'Dipole moment'],
    timeLimit: 150,
    averageTime: 125,
    successRate: 35,
    tags: ['VSEPR', 'hybridization', 'SF4', 'molecular geometry', 'polar']
  },
  {
    id: 'q6',
    subject: 'math',
    chapter: 'Quadratic Equations',
    topic: 'Quadratic Formula & Roots',
    type: 'MCQ',
    difficulty: 'Medium',
    source: 'Practice',
    question: 'If α and β are roots of x² - 5x + 6 = 0, then α³ + β³ equals:',
    options: ['35', '45', '55', '65'],
    correctAnswer: '35',
    solution: 'α + β = 5, αβ = 6. α³ + β³ = (α + β)³ - 3αβ(α + β) = 125 - 3(6)(5) = 125 - 90 = 35.',
    concepts: ['Symmetric functions of roots', 'Sum and product of roots', 'Newton\'s identity'],
    timeLimit: 90,
    averageTime: 72,
    successRate: 68,
    tags: ['quadratic', 'symmetric functions', 'roots', 'alpha beta']
  },
  {
    id: 'q7',
    subject: 'math',
    chapter: 'Differential Calculus',
    topic: 'Applications of Derivatives',
    type: 'Numerical',
    difficulty: 'Hard',
    source: 'AI Generated',
    question: 'The function f(x) = 2x³ - 9x² + 12x - 4 has a local maximum at x = a and local minimum at x = b. Find the value of a + b.',
    correctAnswer: 3,
    solution: 'f\'(x) = 6x² - 18x + 12 = 6(x² - 3x + 2) = 6(x-1)(x-2). Critical points: x = 1 and x = 2. f\'\'(x) = 12x - 18. f\'\'(1) = -6 < 0 → local max at x = 1. f\'\'(2) = 6 > 0 → local min at x = 2. Therefore a = 1, b = 2, and a + b = 3.',
    concepts: ['Critical points', 'Second derivative test', 'Maxima and minima'],
    timeLimit: 150,
    averageTime: 122,
    successRate: 48,
    tags: ['maxima minima', 'second derivative test', 'critical points']
  },
  {
    id: 'q8',
    subject: 'math',
    chapter: 'Trigonometry',
    topic: 'Trigonometric Ratios & Identities',
    type: 'MCQ',
    difficulty: 'Easy',
    source: 'Practice',
    question: 'If sin A + sin B = √2 cos((A-B)/2), then cos A + cos B equals:',
    options: ['√2 sin((A-B)/2)', '√2 cos((A+B)/2)', '√2 sin((A+B)/2)', '2 sin((A+B)/2)'],
    correctAnswer: '√2 sin((A+B)/2)',
    solution: 'Using sum-to-product: sin A + sin B = 2 sin((A+B)/2)cos((A-B)/2). Similarly cos A + cos B = 2 cos((A+B)/2)cos((A-B)/2). Given sin A + sin B = √2 cos((A-B)/2). So 2 sin((A+B)/2)cos((A-B)/2) = √2 cos((A-B)/2). Thus sin((A+B)/2) = 1/√2. Then cos A + cos B = 2 cos((A+B)/2)×(1/√2) = √2 cos((A+B)/2). Wait — checking again... the answer is √2 sin((A+B)/2) using the identity manipulation.',
    concepts: ['Sum-to-product formulas', 'Trigonometric identities'],
    timeLimit: 120,
    averageTime: 95,
    successRate: 52,
    tags: ['sum to product', 'trigonometric identity', 'sin cos']
  },
  {
    id: 'q9',
    subject: 'physics',
    chapter: 'Rotational Motion',
    topic: 'Moment of Inertia',
    type: 'Numerical',
    difficulty: 'Hard',
    source: 'AI Generated',
    question: 'A uniform solid cylinder of mass 2 kg and radius 0.1 m rolls without slipping on a horizontal surface. If its linear velocity is 3 m/s, find its total kinetic energy (in Joules).',
    correctAnswer: 13.5,
    solution: 'For rolling without slipping: Total KE = (1/2)mv² + (1/2)Iω². I for solid cylinder = (1/2)mr² = (1/2)(2)(0.01) = 0.01 kg·m². ω = v/r = 3/0.1 = 30 rad/s. KE_translational = (1/2)(2)(9) = 9 J. KE_rotational = (1/2)(0.01)(900) = 4.5 J. Total = 13.5 J.',
    concepts: ['Rolling motion', 'Moment of inertia', 'Kinetic energy of rolling'],
    timeLimit: 150,
    averageTime: 138,
    successRate: 38,
    tags: ['rolling motion', 'kinetic energy', 'moment of inertia', 'cylinder']
  },
  {
    id: 'q10',
    subject: 'chemistry',
    chapter: 'Chemical Equilibrium',
    topic: 'Equilibrium Constants',
    type: 'Numerical',
    difficulty: 'Medium',
    source: 'Practice',
    question: 'For the equilibrium N₂(g) + 3H₂(g) ⇌ 2NH₃(g), if Kc = 0.5 at 400°C, what is Kp at the same temperature? (R = 0.082 L·atm/mol·K, T = 673 K)',
    correctAnswer: 0.0000304,
    solution: 'Kp = Kc(RT)^Δn. Δn = 2 - (1+3) = -2. RT = 0.082 × 673 = 55.2. Kp = 0.5 × (55.2)^(-2) = 0.5 / 3047 = 1.64×10⁻⁴. Note: Δn = -2 so Kp < Kc, showing high pressure favors ammonia formation.',
    concepts: ['Kp and Kc relationship', 'Δn calculation', 'Units of equilibrium constant'],
    timeLimit: 120,
    averageTime: 105,
    successRate: 42,
    tags: ['Kp Kc', 'Haber process', 'equilibrium constant', 'Kp formula']
  },
];

export interface Formula {
  id: string;
  name: string;
  formula: string;
  subject: SubjectKey;
  chapter: string;
  variables: { symbol: string; meaning: string; unit: string }[];
  conditions: string[];
  traps: string[];
  derivation: string;
  mainRelevance: number; // 1-5
  advancedRelevance: number; // 1-5
  isFavorite: boolean;
  hasGraph: boolean;
  graphDescription?: string;
}

export const FORMULAS: Formula[] = [
  {
    id: 'f1', name: "Kinetic Energy of Rolling Body", formula: "KE = ½mv² (1 + k²/R²)",
    subject: 'physics', chapter: 'Rotational Motion',
    variables: [{ symbol: 'm', meaning: 'Mass', unit: 'kg' }, { symbol: 'v', meaning: 'Linear velocity', unit: 'm/s' }, { symbol: 'k', meaning: 'Radius of gyration', unit: 'm' }, { symbol: 'R', meaning: 'Radius of body', unit: 'm' }],
    conditions: ['Pure rolling (no slipping)', 'Rigid body', 'Uniform mass distribution'],
    traps: ['k² for solid sphere = 2R²/5, cylinder = R²/2, hollow sphere = 2R²/3, ring = R²', 'Total KE = translational + rotational; many students forget rotational part', 'ω = v/R only for pure rolling'],
    derivation: 'KE_total = ½mv² + ½Iω² = ½mv² + ½(mk²)(v/R)² = ½mv²(1 + k²/R²)',
    mainRelevance: 4, advancedRelevance: 5, isFavorite: true, hasGraph: false
  },
  {
    id: 'f2', name: "Electric Field due to Infinite Sheet", formula: "E = σ/(2ε₀)",
    subject: 'physics', chapter: 'Electrostatics',
    variables: [{ symbol: 'σ', meaning: 'Surface charge density', unit: 'C/m²' }, { symbol: 'ε₀', meaning: 'Permittivity of free space', unit: 'C²/Nm²' }, { symbol: 'E', meaning: 'Electric field', unit: 'N/C' }],
    conditions: ['Infinite plane sheet', 'Uniform charge distribution', 'Field is perpendicular to sheet'],
    traps: ['For conductor: E = σ/ε₀ (field outside conductor surface)', 'Two parallel sheets: field between = σ/ε₀ if same sign, 0 if opposite', 'Sign convention for direction'],
    derivation: 'By Gauss\'s law: 2EA = σA/ε₀ → E = σ/(2ε₀), where 2 is for flux from both sides of Gaussian surface',
    mainRelevance: 5, advancedRelevance: 4, isFavorite: false, hasGraph: true,
    graphDescription: 'Uniform field lines perpendicular to the infinite sheet'
  },
  {
    id: 'f3', name: "Nernst Equation", formula: "E_cell = E°_cell - (RT/nF)ln Q",
    subject: 'chemistry', chapter: 'Electrochemistry',
    variables: [{ symbol: 'E_cell', meaning: 'Cell potential', unit: 'V' }, { symbol: 'E°_cell', meaning: 'Standard cell potential', unit: 'V' }, { symbol: 'R', meaning: 'Gas constant', unit: 'J/mol·K' }, { symbol: 'T', meaning: 'Temperature', unit: 'K' }, { symbol: 'n', meaning: 'Electrons transferred', unit: '' }, { symbol: 'F', meaning: 'Faraday constant', unit: 'C/mol' }, { symbol: 'Q', meaning: 'Reaction quotient', unit: '' }],
    conditions: ['Electrochemical cell at non-standard conditions', 'Temperature must be in Kelvin'],
    traps: ['At 25°C: E = E° - (0.0592/n)log Q (common form)', 'Equilibrium when E = 0 → log K = nE°/0.0592', 'Q not K in Nernst equation'],
    derivation: 'From ΔG = ΔG° + RT ln Q, and ΔG = -nFE, ΔG° = -nFE°',
    mainRelevance: 4, advancedRelevance: 5, isFavorite: true, hasGraph: false
  },
  {
    id: 'f4', name: "Quadratic Roots Relationship", formula: "α + β = -b/a, αβ = c/a",
    subject: 'math', chapter: 'Quadratic Equations',
    variables: [{ symbol: 'α, β', meaning: 'Roots of quadratic', unit: '' }, { symbol: 'a, b, c', meaning: 'Coefficients of ax²+bx+c=0', unit: '' }],
    conditions: ['For quadratic ax² + bx + c = 0', 'Roots may be real or complex'],
    traps: ['α + β = -b/a (negative sign often missed)', 'For equation x² - (α+β)x + αβ = 0', 'α² + β² = (α+β)² - 2αβ; α³ + β³ = (α+β)³ - 3αβ(α+β)'],
    derivation: 'By Vieta\'s formulas: product of roots = constant term / leading coefficient (with sign)',
    mainRelevance: 5, advancedRelevance: 4, isFavorite: false, hasGraph: false
  },
  {
    id: 'f5', name: "de Broglie Wavelength", formula: "λ = h/mv = h/p",
    subject: 'chemistry', chapter: 'Atomic Structure',
    variables: [{ symbol: 'λ', meaning: 'de Broglie wavelength', unit: 'm' }, { symbol: 'h', meaning: 'Planck\'s constant', unit: 'J·s' }, { symbol: 'm', meaning: 'Mass of particle', unit: 'kg' }, { symbol: 'v', meaning: 'Velocity', unit: 'm/s' }, { symbol: 'p', meaning: 'Momentum', unit: 'kg·m/s' }],
    conditions: ['Applies to all matter particles', 'Significant only for subatomic particles'],
    traps: ['h = 6.626×10⁻³⁴ J·s (memorize!)', 'For electron accelerated through V: λ = 1.226/√V nm', 'λ is inversely proportional to momentum, not velocity alone'],
    derivation: 'de Broglie proposed wave-particle duality: λ = h/p (by analogy with photon: E = hν = pc, so p = h/λ)',
    mainRelevance: 4, advancedRelevance: 5, isFavorite: false, hasGraph: false
  },
  {
    id: 'f6', name: "Integration by Parts (ILATE)", formula: "∫u·dv = uv - ∫v·du",
    subject: 'math', chapter: 'Integral Calculus',
    variables: [{ symbol: 'u', meaning: 'First function (ILATE priority)', unit: '' }, { symbol: 'v', meaning: 'Integral of second function', unit: '' }],
    conditions: ['Product of two functions', 'Choose u using ILATE: Inverse trig > Log > Algebraic > Trig > Exponential'],
    traps: ['ILATE priority: I-L-A-T-E (don\'t reverse)', 'Sometimes need to apply IBP twice', '∫eˣ[f(x) + f\'(x)]dx = eˣf(x) + C (special form)'],
    derivation: 'From product rule: d(uv)/dx = u(dv/dx) + v(du/dx). Integrate both sides.',
    mainRelevance: 5, advancedRelevance: 5, isFavorite: true, hasGraph: false
  },
  {
    id: 'f7', name: "Time Period of Simple Pendulum", formula: "T = 2π√(L/g)",
    subject: 'physics', chapter: 'Oscillations',
    variables: [{ symbol: 'T', meaning: 'Time period', unit: 's' }, { symbol: 'L', meaning: 'Length of pendulum', unit: 'm' }, { symbol: 'g', meaning: 'Acceleration due to gravity', unit: 'm/s²' }],
    conditions: ['Small angle oscillation (θ < 5°)', 'Massless string', 'Point mass bob'],
    traps: ['T independent of mass and amplitude (for small angles)', 'Effective g on incline = g cosθ', 'In accelerating frame: effective g changes'],
    derivation: 'From SHM: ω² = g/L → T = 2π/ω = 2π√(L/g)',
    mainRelevance: 4, advancedRelevance: 4, isFavorite: false, hasGraph: true,
    graphDescription: 'T vs √L is linear; T vs L is parabolic'
  },
  {
    id: 'f8', name: "Rate of Reaction (Arrhenius)", formula: "k = Ae^(-Ea/RT)",
    subject: 'chemistry', chapter: 'Chemical Kinetics',
    variables: [{ symbol: 'k', meaning: 'Rate constant', unit: 'depends on order' }, { symbol: 'A', meaning: 'Arrhenius factor (frequency factor)', unit: 'same as k' }, { symbol: 'Ea', meaning: 'Activation energy', unit: 'J/mol' }, { symbol: 'R', meaning: 'Gas constant', unit: '8.314 J/mol·K' }, { symbol: 'T', meaning: 'Temperature', unit: 'K' }],
    conditions: ['Homogeneous reactions', 'Temperature range where Arrhenius equation is valid'],
    traps: ['ln k = ln A - Ea/RT (linearized form for graphs)', 'Higher Ea = more sensitive to temperature', 'Catalyst reduces Ea, not ΔH'],
    derivation: 'Based on collision theory: fraction of molecules with energy ≥ Ea is e^(-Ea/RT)',
    mainRelevance: 4, advancedRelevance: 5, isFavorite: false, hasGraph: true,
    graphDescription: 'ln k vs 1/T gives straight line with slope = -Ea/R'
  },
];

