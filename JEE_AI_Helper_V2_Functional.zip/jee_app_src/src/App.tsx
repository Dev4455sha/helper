import { useEffect, useState } from 'react';
import Sidebar from './components/Sidebar';
import AuthGate from './components/AuthGate';
import Dashboard from './pages/Dashboard';
import Syllabus from './pages/Syllabus';
import Practice from './pages/Practice';
import Tests from './pages/Tests';
import Analytics from './pages/Analytics';
import AICoach from './pages/AICoach';
import FormulaBank from './pages/FormulaBank';
import ErrorLog from './pages/ErrorLog';
import RevisionTracker from './pages/RevisionTracker';
import Roadmap from './pages/Roadmap';
import DailyPlanner from './pages/DailyPlanner';
import { ConceptMap, DoubtSolver, OfficialJEE, CollegeCounselling, Achievements, SettingsPage, Resources } from './pages/OtherPages';
import { currentUser, getStore, logout, setFocus } from './lib/appStore';

type NavId = 'dashboard'|'roadmap'|'planner'|'syllabus-physics'|'syllabus-chemistry'|'syllabus-math'|'practice-qbank'|'practice-pyq'|'practice-custom'|'tests-main'|'tests-advanced'|'tests-custom'|'errorlog'|'revision'|'formulabank'|'conceptmap'|'aicoach'|'doubtsolver'|'analytics'|'resources'|'achievements'|'official'|'college'|'settings';

function PageRenderer({page,onNav}:{page:NavId;onNav:(id:NavId)=>void}){
  switch(page){
    case'dashboard':return <Dashboard onNav={onNav}/>;
    case'roadmap':return <Roadmap onNav={onNav}/>;
    case'planner':return <DailyPlanner onNav={onNav}/>;
    case'syllabus-physics':return <Syllabus subject="physics" onNav={onNav}/>;
    case'syllabus-chemistry':return <Syllabus subject="chemistry" onNav={onNav}/>;
    case'syllabus-math':return <Syllabus subject="math" onNav={onNav}/>;
    case'practice-qbank':return <Practice mode="qbank"/>;
    case'practice-pyq':return <Practice mode="pyq"/>;
    case'practice-custom':return <Practice mode="custom"/>;
    case'tests-main':return <Tests mode="main"/>;
    case'tests-advanced':return <Tests mode="advanced"/>;
    case'tests-custom':return <Tests mode="custom"/>;
    case'errorlog':return <ErrorLog/>;
    case'revision':return <RevisionTracker/>;
    case'formulabank':return <FormulaBank/>;
    case'conceptmap':return <ConceptMap/>;
    case'aicoach':return <AICoach/>;
    case'doubtsolver':return <DoubtSolver/>;
    case'analytics':return <Analytics/>;
    case'resources':return <Resources/>;
    case'achievements':return <Achievements/>;
    case'official':return <OfficialJEE/>;
    case'college':return <CollegeCounselling/>;
    case'settings':return <SettingsPage/>;
    default:return <Dashboard onNav={onNav}/>;
  }
}

const FULL:NavId[]=['aicoach','doubtsolver','tests-main','tests-advanced','tests-custom'];

export default function App(){
  const [user,setUser]=useState(currentUser());
  const [activePage,setActivePage]=useState<NavId>('dashboard');
  useEffect(()=>{const sync=()=>setUser(currentUser());window.addEventListener('jee-store-change',sync);window.addEventListener('storage',sync);return()=>{window.removeEventListener('jee-store-change',sync);window.removeEventListener('storage',sync)}},[]);
  useEffect(()=>{const before=()=>{if(getStore().focus.active) { try{window.localStorage.setItem('jee-focus-warning','1')}catch{} } };window.addEventListener('beforeunload',before);return()=>window.removeEventListener('beforeunload',before)},[]);
  if(!user) return <AuthGate onAuth={()=>setUser(currentUser())}/>;
  const navigate=(id:NavId)=>{if(getStore().focus.active&&id!=='planner'){if(!window.confirm('Focus Mode is active. Leave it and end the session?'))return;setFocus('',false);}setActivePage(id)};
  const doLogout=()=>{if(getStore().focus.active&&!window.confirm('A focus session is active. Logout and end it?'))return;logout();setUser(null)};
  const full=FULL.includes(activePage);
  return <div className="flex h-screen overflow-hidden bg-[var(--background)]"><Sidebar active={activePage} onNav={navigate} onLogout={doLogout}/><main className="flex-1 overflow-hidden"><div className={full?'h-full overflow-hidden':'h-full overflow-y-auto'}><PageRenderer page={activePage} onNav={navigate}/></div></main></div>;
}
