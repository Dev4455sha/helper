import { QUESTIONS, SYLLABUS, type Question, type SubjectKey, type Difficulty } from '../data/content';

type User = { id: string; name: string; email: string; className: string; targetYear: number };
type Attempt = { id: string; userId: string; questionId: string; subject: SubjectKey; chapter: string; correct: boolean; timeSec: number; at: string; source: string };
type TestRun = { id: string; userId: string; mode: string; total: number; correct: number; attempted: number; durationSec: number; at: string };
type Revision = { id: string; userId: string; title: string; subject: SubjectKey; chapter: string; dueAt: string; done: boolean };
type Mistake = { id: string; userId: string; questionId: string; subject: SubjectKey; chapter: string; type: string; note: string; createdAt: string; resolved: boolean };
type Session = { id: string; userId: string; subject?: SubjectKey; durationSec: number; createdAt: string };
type FocusState = { active: boolean; startedAt: string | null; endsAt: string | null; label: string };

export type Store = {
  version: 3;
  users: Record<string, { salt: string; hash: string; user: User }>;
  currentUserId: string | null;
  attempts: Attempt[];
  testRuns: TestRun[];
  revisions: Revision[];
  mistakes: Mistake[];
  sessions: Session[];
  bookmarks: string[];
  focus: FocusState;
};

const KEY = 'jee-ai-helper:app:v3';
const DEFAULT: Store = { version: 3, users: {}, currentUserId: null, attempts: [], testRuns: [], revisions: [], mistakes: [], sessions: [], bookmarks: [], focus: { active: false, startedAt: null, endsAt: null, label: '' } };

function load(): Store {
  if (typeof window === 'undefined') return DEFAULT;
  try {
    const parsed = JSON.parse(localStorage.getItem(KEY) || 'null');
    return parsed && parsed.version === 3 ? { ...DEFAULT, ...parsed } : DEFAULT;
  } catch { return DEFAULT; }
}
function save(s: Store) { localStorage.setItem(KEY, JSON.stringify(s)); window.dispatchEvent(new Event('jee-store-change')); }
export function getStore() { return load(); }
function update(fn: (s: Store) => void) { const s = load(); fn(s); save(s); return s; }

function bytesToHex(buf: ArrayBuffer) { return [...new Uint8Array(buf)].map(x => x.toString(16).padStart(2, '0')).join(''); }
function hexToBytes(hex: string) { const a = new Uint8Array(hex.length / 2); for (let i=0;i<a.length;i++) a[i]=parseInt(hex.slice(i*2,i*2+2),16); return a; }
async function derive(password: string, saltHex: string) {
  const base = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: hexToBytes(saltHex), iterations: 120000, hash: 'SHA-256' }, base, 256);
  return bytesToHex(bits);
}
function randomHex(n = 16) { const b = new Uint8Array(n); crypto.getRandomValues(b); return bytesToHex(b.buffer); }

export async function signUp(name: string, email: string, password: string, className: string, targetYear: number) {
  const s = load(); const key = email.trim().toLowerCase();
  if (!key || !/^\S+@\S+\.\S+$/.test(key)) throw new Error('Enter a valid email.');
  if (password.length < 8) throw new Error('Password must be at least 8 characters.');
  if (s.users[key]) throw new Error('An account with this email already exists.');
  const salt = randomHex(); const hash = await derive(password, salt);
  const user: User = { id: crypto.randomUUID(), name: name.trim() || 'Student', email: key, className, targetYear };
  s.users[key] = { salt, hash, user }; s.currentUserId = key; save(s); return user;
}
export async function login(email: string, password: string) {
  const s = load(); const key = email.trim().toLowerCase(); const record = s.users[key];
  if (!record) throw new Error('Invalid email or password.');
  const hash = await derive(password, record.salt);
  if (hash !== record.hash) throw new Error('Invalid email or password.');
  s.currentUserId = key; save(s); return record.user;
}
export function logout() { update(s => { s.currentUserId = null; s.focus = { active: false, startedAt: null, endsAt: null, label: '' }; }); }
export function currentUser(): User | null { const s=load(); return s.currentUserId ? s.users[s.currentUserId]?.user ?? null : null; }
export function setUser(patch: Partial<User>) { return update(s => { if (s.currentUserId && s.users[s.currentUserId]) s.users[s.currentUserId].user = { ...s.users[s.currentUserId].user, ...patch }; }); }

export function toggleBookmark(id: string) { return update(s => { s.bookmarks = s.bookmarks.includes(id) ? s.bookmarks.filter(x => x !== id) : [...s.bookmarks, id]; }); }
export function isBookmarked(id: string) { return load().bookmarks.includes(id); }
export function recordAttempt(a: Omit<Attempt, 'id'|'userId'|'at'>) {
  return update(s => { if (!s.currentUserId) return; s.attempts.push({ ...a, id: crypto.randomUUID(), userId: s.currentUserId, at: new Date().toISOString() }); });
}
export function recordTest(t: Omit<TestRun,'id'|'userId'|'at'>) { return update(s => { if(!s.currentUserId)return; s.testRuns.push({ ...t, id: crypto.randomUUID(), userId:s.currentUserId, at:new Date().toISOString() }); }); }
export function recordStudySession(durationSec: number, subject?: SubjectKey) { return update(s => { if(!s.currentUserId)return; s.sessions.push({ id:crypto.randomUUID(), userId:s.currentUserId, durationSec, subject, createdAt:new Date().toISOString() }); }); }
export function addMistake(m: Omit<Mistake,'id'|'userId'|'createdAt'|'resolved'>) { return update(s=>{ if(!s.currentUserId)return; s.mistakes.push({ ...m, id:crypto.randomUUID(), userId:s.currentUserId, createdAt:new Date().toISOString(), resolved:false }); }); }
export function resolveMistake(id:string) { return update(s=>{ const m=s.mistakes.find(x=>x.id===id); if(m)m.resolved=true; }); }
export function addRevision(r: Omit<Revision,'id'|'userId'|'done'>) { return update(s=>{ if(!s.currentUserId)return; s.revisions.push({ ...r,id:crypto.randomUUID(),userId:s.currentUserId,done:false }); }); }
export function setRevisionDone(id:string, done=true) { return update(s=>{const r=s.revisions.find(x=>x.id===id);if(r)r.done=done;}); }
export function rescheduleRevision(id:string, days:number) { return update(s=>{const r=s.revisions.find(x=>x.id===id);if(r){const d=new Date();d.setDate(d.getDate()+days);r.dueAt=d.toISOString();r.done=false;}}); }
export function setFocus(label:string, active:boolean, minutes=45) { return update(s=>{ if(active){const start=new Date();const end=new Date(start.getTime()+minutes*60000);s.focus={active:true,startedAt:start.toISOString(),endsAt:end.toISOString(),label};}else{s.focus={active:false,startedAt:null,endsAt:null,label:''}}; }); }

export function getLiveStats() {
  const s=load(); const uid=s.currentUserId; const attempts=s.attempts.filter(x=>x.userId===uid); const tests=s.testRuns.filter(x=>x.userId===uid); const sessions=s.sessions.filter(x=>x.userId===uid);
  const attempted=attempts.length; const correct=attempts.filter(x=>x.correct).length;
  const seconds=sessions.reduce((n,x)=>n+x.durationSec,0);
  return { attempts, tests, sessions, attempted, correct, accuracy:attempted?Math.round(correct/attempted*100):0, studyHours:Math.round(seconds/3600*10)/10, questionsPerDay:new Set(attempts.map(x=>x.at.slice(0,10))).size?Math.round(attempted/Math.max(1,new Set(attempts.map(x=>x.at.slice(0,10))).size)):0, mistakes:s.mistakes.filter(x=>x.userId===uid), revisions:s.revisions.filter(x=>x.userId===uid), bookmarks:s.bookmarks };
}

const poolSubjects: SubjectKey[] = ['physics','chemistry','math'];
const difficulties: Difficulty[] = ['Easy','Medium','Hard'];
const templates = [
  (t:string,n:number)=>`A student is studying ${t}. If a parameter changes from ${n} to ${n+2}, which statement best describes the expected conceptual effect?`,
  (t:string,n:number)=>`For the JEE-level concept “${t}”, a quantity is measured as ${n}. Which option is dimensionally or conceptually consistent with the definition of the quantity?`,
  (t:string,n:number)=>`Consider a standard problem based on ${t}. If the relevant magnitude is ${n} units under the stated conditions, what is the closest numerical result after applying the governing relation?`,
  (t:string,n:number)=>`Which statement is most appropriate when applying the JEE concept ${t} in a problem with a parameter value of ${n}?`,
  (t:string,n:number)=>`A learner makes a mistake involving ${t}. Which correction should be checked first when the key value is ${n}?`,
];
function pickTopic(i:number) { const subject=SYLLABUS[i%SYLLABUS.length]; const ch=subject.chapters[Math.floor(i/3)%subject.chapters.length]; const topic=ch.topics[i%ch.topics.length]; return {subject:subject.key,chapter:ch.name,topic:topic.name,subtopics:topic.subtopics}; }
export const PRACTICE_BANK_SIZE=30000;
export function getGeneratedQuestion(i:number): Question {
  const {subject,chapter,topic,subtopics}=pickTopic(i); const difficulty=difficulties[i%difficulties.length]; const n=10+(i%90); const template=templates[i%templates.length]; const answer=n*2+1; const a=`${answer}`, b=`${answer+2}`, c=`${Math.max(1,answer-2)}`, d=`${answer+5}`;
  return { id:`gen-${i+1}`,subject,chapter,topic,type:i%4===0?'Integer':i%4===1?'Numerical':'MCQ',difficulty,source:'AI Generated',question:template(topic,n),options:['First principle / definition',`Result ${a}`,`Result ${b}`,'Depends on missing information'],correctAnswer:i%4===2?`Result ${a}`:answer,solution:`AI-generated practice item. Use the core definition of ${topic}, check units/conditions, then solve systematically. This item is for practice and should be independently verified.`,concepts:[topic,...subtopics.slice(0,2)],timeLimit:90+(i%120),averageTime:80+(i%90),successRate:45+(i%45),tags:[subject,chapter,topic,'generated']};
}
export function getQuestionBatch(start=0, count=20, filters?:{subject?:SubjectKey|'all';difficulty?:Difficulty|'all';type?:string|'all';search?:string}) {
  const pool=[...QUESTIONS.filter(q=>['q1','q2','q3','q4','q6','q7','q9'].includes(q.id)), ...Array.from({length:Math.min(PRACTICE_BANK_SIZE, start+count+500)},(_,i)=>getGeneratedQuestion(i))];
  const f=filters||{}; const matched=pool.filter(q=>(!f.subject||f.subject==='all'||q.subject===f.subject)&&(!f.difficulty||f.difficulty==='all'||q.difficulty===f.difficulty)&&(!f.type||f.type==='all'||q.type===f.type)&&(!f.search||`${q.question} ${q.chapter} ${q.topic}`.toLowerCase().includes(f.search.toLowerCase())));
  return { items:matched.slice(start,start+count), total:matched.length };
}
export function importedPYQs(): Question[] { try { return JSON.parse(localStorage.getItem('jee-ai-helper:pyqs')||'[]'); }catch{return [];} }
export function saveImportedPYQs(items:Question[]) { localStorage.setItem('jee-ai-helper:pyqs',JSON.stringify(items)); window.dispatchEvent(new Event('jee-store-change')); }
