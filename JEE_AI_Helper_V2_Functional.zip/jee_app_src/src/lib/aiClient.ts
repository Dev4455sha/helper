export async function askAI(prompt:string, context?:unknown, image?:{data:string;mimeType:string}){
  const response=await fetch('/api/ai',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt,context,image})});
  const data=await response.json().catch(()=>({}));
  if(!response.ok) throw new Error(data?.error||`AI request failed (${response.status})`);
  return String(data.text||'');
}
