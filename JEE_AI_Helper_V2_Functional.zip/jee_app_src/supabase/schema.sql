-- Optional production schema for Supabase/Postgres.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null,
  class_name text not null default 'Class 12',
  target_year int not null,
  created_at timestamptz not null default now()
);

create table if not exists public.attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  question_id text not null,
  subject text not null,
  chapter text not null,
  correct boolean not null,
  time_sec int not null default 0,
  source text not null,
  attempted_at timestamptz not null default now()
);

create table if not exists public.test_runs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  mode text not null,
  total int not null,
  correct int not null,
  attempted int not null,
  duration_sec int not null,
  created_at timestamptz not null default now()
);

create table if not exists public.mistakes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  question_id text not null,
  subject text not null,
  chapter text not null,
  type text not null,
  note text not null,
  resolved boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.revisions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  subject text not null,
  chapter text not null,
  due_at timestamptz not null,
  done boolean not null default false
);

create table if not exists public.study_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  subject text,
  duration_sec int not null,
  created_at timestamptz not null default now()
);

create table if not exists public.bookmarks (
  user_id uuid not null references auth.users(id) on delete cascade,
  question_id text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, question_id)
);

alter table public.profiles enable row level security;
alter table public.attempts enable row level security;
alter table public.test_runs enable row level security;
alter table public.mistakes enable row level security;
alter table public.revisions enable row level security;
alter table public.study_sessions enable row level security;
alter table public.bookmarks enable row level security;

create policy profiles_self on public.profiles for all using (auth.uid() = id) with check (auth.uid() = id);
create policy attempts_self on public.attempts for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy test_runs_self on public.test_runs for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy mistakes_self on public.mistakes for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy revisions_self on public.revisions for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy study_sessions_self on public.study_sessions for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy bookmarks_self on public.bookmarks for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
